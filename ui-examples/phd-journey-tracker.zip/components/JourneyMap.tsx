import React, { useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import { Playbook, WorldData, JourneyNodeData, Locale, getLocalizedText } from '../types';
import { WorldContainer } from './WorldContainer';
import { cn } from '../lib/utils';
import { Rocket, Sparkles, FileText, UploadCloud, Check } from 'lucide-react';

interface JourneyMapProps {
  playbook: Playbook;
  currentActiveNodeId?: string; // If undefined, assumes start
  locale: Locale;
}

export const JourneyMap: React.FC<JourneyMapProps> = ({ playbook, currentActiveNodeId, locale }) => {
  // --- State Processing Logic ---
  // We need to flatten the journey to calculate "Done", "Active", "Locked" based on linear position.
  
  const processedWorlds = useMemo(() => {
    let foundActive = false;
    let globalTotalNodes = 0;
    let globalCompletedNodes = 0;

    const newWorlds: WorldData[] = playbook.worlds.map((world, wIndex) => {
      const worldColor = playbook.ui.worlds_palette[wIndex % playbook.ui.worlds_palette.length];
      
      let worldCompletedNodes = 0;

      const newNodes = world.nodes.map((node) => {
        let state: JourneyNodeData['state'] = 'locked';

        if (!currentActiveNodeId && wIndex === 0 && node === world.nodes[0]) {
           state = 'active'; // Default start
           foundActive = true;
        } else if (foundActive) {
          state = 'locked';
        } else if (node.id === currentActiveNodeId) {
          state = 'active';
          foundActive = true;
        } else {
          state = 'done';
          worldCompletedNodes++;
          globalCompletedNodes++;
        }

        return { ...node, state };
      });

      // Calculate World Status
      let worldStatus: WorldData['status'] = 'locked';
      if (newNodes.some(n => n.state === 'active')) {
        worldStatus = 'active';
      } else if (newNodes.every(n => n.state === 'done')) {
        worldStatus = 'completed';
      } else if (newNodes.some(n => n.state === 'done')) {
        // Should not strictly happen in linear model unless active is in this world
        worldStatus = 'active'; 
      }

      // If previous world was completed and this one has no progress yet, it might be active waiting to start
      // But our node logic above handles "foundActive", so if a node is active here, world is active.
      
      globalTotalNodes += world.nodes.length;

      return {
        ...world,
        nodes: newNodes,
        status: worldStatus,
        color: worldColor,
        progress: (worldCompletedNodes / world.nodes.length) * 100
      };
    });

    return { worlds: newWorlds, globalProgress: (globalCompletedNodes / globalTotalNodes) * 100 };
  }, [playbook, currentActiveNodeId]);

  const [selectedNode, setSelectedNode] = useState<JourneyNodeData | null>(null);

  return (
    <div className="max-w-3xl mx-auto pb-20">
      {/* Sticky Global Header */}
      <div className="sticky top-0 z-50 bg-slate-50/90 backdrop-blur-md border-b border-slate-200 mb-8 -mx-4 px-4 sm:mx-0 sm:px-0 sm:rounded-b-2xl shadow-sm transition-all duration-300">
        <div className="max-w-3xl mx-auto py-4">
          <div className="flex justify-between items-end mb-2 px-2">
            <div>
              <h1 className="text-2xl font-black text-slate-800 tracking-tight flex items-center gap-2">
                <Rocket className="text-primary-500" fill="currentColor" /> 
                PhD Journey
              </h1>
              <p className="text-sm text-slate-500 font-medium">
                {Math.round(processedWorlds.globalProgress)}% Complete
              </p>
            </div>
            {processedWorlds.globalProgress === 100 && (
              <div className="bg-emerald-100 text-emerald-700 px-3 py-1 rounded-full text-xs font-bold flex items-center gap-1">
                <Sparkles size={14} /> Degree Awarded
              </div>
            )}
          </div>
          
          {/* Global Progress Bar */}
          <div className="h-2 w-full bg-slate-200 rounded-full overflow-hidden">
            <motion.div 
              initial={{ width: 0 }}
              animate={{ width: `${processedWorlds.globalProgress}%` }}
              transition={{ duration: 1.5, ease: "easeOut" }}
              className="h-full bg-gradient-to-r from-primary-500 to-indigo-600 shadow-[0_0_10px_rgba(59,130,246,0.5)]"
            />
          </div>
        </div>
      </div>

      {/* World List */}
      <div className="space-y-2 px-2 sm:px-0">
        {processedWorlds.worlds.map((world, index) => (
          <WorldContainer 
            key={world.id}
            world={world}
            index={index}
            locale={locale}
            onNodeClick={setSelectedNode}
          />
        ))}
      </div>

      {/* Detail Modal (Simple Implementation) */}
      {selectedNode && (
        <div className="fixed inset-0 z-[60] flex items-end sm:items-center justify-center p-0 sm:p-4 bg-slate-900/40 backdrop-blur-sm" onClick={() => setSelectedNode(null)}>
          <motion.div 
            initial={{ y: "100%" }}
            animate={{ y: 0 }}
            exit={{ y: "100%" }}
            className="bg-white w-full max-w-lg rounded-t-2xl sm:rounded-2xl shadow-2xl overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="p-6">
              <div className="flex items-start gap-4 mb-4">
                <div className="p-3 bg-primary-100 text-primary-600 rounded-xl">
                  <FileText size={24} />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-slate-900">{getLocalizedText(selectedNode.title, locale)}</h3>
                  <span className="text-xs uppercase tracking-wider font-semibold text-slate-400">
                    {selectedNode.type} • {selectedNode.state.replace('_', ' ')}
                  </span>
                </div>
              </div>
              <div className="prose prose-slate prose-sm max-w-none text-slate-600 bg-slate-50 p-4 rounded-xl mb-6">
                <p>{getLocalizedText(selectedNode.description, locale) || "No description available."}</p>
              </div>

              {selectedNode.requirements && (
                 <div className="mb-6">
                    <h4 className="text-sm font-bold text-slate-900 mb-2">Requirements</h4>
                    <ul className="space-y-2">
                       {selectedNode.requirements.uploads?.map((u: any, i: number) => (
                         <li key={i} className="flex items-center gap-2 text-sm text-slate-600 p-2 border border-slate-100 rounded-lg">
                           <UploadCloud size={14} className="text-slate-400" />
                           {getLocalizedText(u.label, locale)}
                         </li>
                       ))}
                       {selectedNode.requirements.fields?.map((f: any, i: number) => (
                         <li key={i} className="flex items-center gap-2 text-sm text-slate-600 p-2 border border-slate-100 rounded-lg">
                           <Check size={14} className="text-slate-400" />
                           {getLocalizedText(f.label, locale)}
                         </li>
                       ))}
                    </ul>
                 </div>
              )}

              <button 
                onClick={() => setSelectedNode(null)}
                className="w-full py-3 bg-primary-600 hover:bg-primary-700 text-white font-semibold rounded-xl transition-colors"
              >
                Close Details
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
};