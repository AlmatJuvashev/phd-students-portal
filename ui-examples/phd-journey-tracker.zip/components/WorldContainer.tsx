import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDown, Lock, Trophy } from 'lucide-react';
import { WorldData, JourneyNodeData, Locale, getLocalizedText } from '../types';
import { JourneyNode } from './JourneyNode';
import { cn } from '../lib/utils';

interface WorldContainerProps {
  world: WorldData;
  index: number;
  locale: Locale;
  onNodeClick: (node: JourneyNodeData) => void;
}

export const WorldContainer: React.FC<WorldContainerProps> = ({ world, index, locale, onNodeClick }) => {
  // Auto-collapse if world is completed or locked to focus on active world
  const [isOpen, setIsOpen] = useState(world.status === 'active');
  
  // Custom color from palette or default
  const accentColor = world.color || '#3b82f6';

  return (
    <div className={cn(
      "mb-8 rounded-3xl overflow-hidden border border-slate-200 shadow-sm transition-all duration-500",
      world.status === 'active' ? "bg-white ring-1 ring-slate-200 shadow-xl scale-[1.01]" : "bg-slate-50 opacity-90"
    )}>
      {/* World Header */}
      <button 
        onClick={() => world.status !== 'locked' && setIsOpen(!isOpen)}
        className={cn(
          "w-full flex items-center justify-between p-6 transition-colors",
          world.status === 'locked' ? "cursor-not-allowed" : "hover:bg-slate-50/80"
        )}
      >
        <div className="flex items-center gap-4">
          <div 
            className="flex items-center justify-center w-12 h-12 rounded-xl text-white font-bold text-lg shadow-sm"
            style={{ backgroundColor: world.status === 'locked' ? '#94a3b8' : accentColor }}
          >
            {world.status === 'completed' ? <Trophy size={20} /> : world.order}
          </div>
          <div className="text-left">
            <h3 className={cn("text-xl font-bold", world.status === 'locked' ? "text-slate-400" : "text-slate-800")}>
              {getLocalizedText(world.title, locale)}
            </h3>
            <div className="flex items-center gap-2 mt-1">
               {/* Mini Progress Bar */}
               <div className="w-24 h-1.5 bg-slate-200 rounded-full overflow-hidden">
                 <div 
                   className="h-full rounded-full transition-all duration-1000"
                   style={{ 
                     width: `${world.progress}%`, 
                     backgroundColor: world.status === 'locked' ? '#cbd5e1' : accentColor 
                   }}
                 />
               </div>
               <span className="text-xs text-slate-400 font-medium">
                 {Math.round(world.progress)}%
               </span>
            </div>
          </div>
        </div>

        <div className="text-slate-400">
          {world.status === 'locked' ? (
            <Lock size={20} />
          ) : (
            <motion.div animate={{ rotate: isOpen ? 180 : 0 }}>
              <ChevronDown size={24} />
            </motion.div>
          )}
        </div>
      </button>

      {/* Collapsible Content */}
      <AnimatePresence>
        {isOpen && world.status !== 'locked' && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <div className="px-4 sm:px-8 pb-8 pt-2">
              <div className="relative pl-0 sm:pl-2">
                 {/* Visual connector from Header to first node */}
                 <div className="absolute left-[2.2rem] sm:left-12 top-[-1rem] h-8 w-[3px] bg-slate-200/60 rounded-full -z-10" />

                 {world.nodes.map((node, i) => (
                   <JourneyNode 
                     key={node.id} 
                     node={node} 
                     index={i} 
                     isLast={i === world.nodes.length - 1} 
                     locale={locale}
                     onClick={onNodeClick}
                   />
                 ))}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};