import React from 'react';
import { motion } from 'framer-motion';
import { 
  Check, 
  Lock, 
  FileText, 
  Flag, 
  Shield, 
  UploadCloud, 
  AlertCircle,
  ChevronRight,
  Info,
  GraduationCap,
  Star
} from 'lucide-react';
import { JourneyNodeData, NodeState, NodeType, Locale, getLocalizedText } from '../types';
import { JourneyPath } from './JourneyPath';
import { cn } from '../lib/utils';

interface JourneyNodeProps {
  node: JourneyNodeData;
  index: number;
  isLast: boolean;
  locale: Locale;
  onClick: (node: JourneyNodeData) => void;
}

const getNodeIcon = (type: NodeType) => {
  switch (type) {
    case 'milestone': return Flag;
    case 'gateway': return Shield;
    case 'upload': return UploadCloud;
    case 'form': return FileText;
    case 'confirmTask': return Check;
    case 'info': return Info;
    case 'task': return Star;
    default: return FileText;
  }
};

const getStatusStyles = (state: NodeState) => {
  switch (state) {
    case 'done':
      return {
        wrapper: 'border-emerald-500/50 bg-gradient-to-br from-emerald-50 to-white shadow-sm',
        iconBg: 'bg-gradient-to-br from-emerald-400 to-emerald-600 shadow-emerald-200',
        iconColor: 'text-white',
        text: 'text-slate-600',
        title: 'text-slate-700',
        badge: 'bg-emerald-100 text-emerald-700'
      };
    case 'active':
      return {
        wrapper: 'border-primary-500 bg-white ring-4 ring-primary-100 shadow-lg scale-[1.02]',
        iconBg: 'bg-gradient-to-br from-primary-500 to-blue-600 shadow-blue-200',
        iconColor: 'text-white',
        text: 'text-slate-600',
        title: 'text-primary-800',
        badge: 'bg-blue-100 text-blue-700'
      };
    case 'needs_fixes':
      return {
        wrapper: 'border-amber-500 bg-amber-50',
        iconBg: 'bg-amber-500',
        iconColor: 'text-white',
        text: 'text-amber-700',
        title: 'text-amber-900',
        badge: 'bg-amber-100 text-amber-800'
      };
    case 'waiting':
      return {
        wrapper: 'border-indigo-200 bg-slate-50',
        iconBg: 'bg-indigo-100',
        iconColor: 'text-indigo-400',
        text: 'text-slate-500',
        title: 'text-slate-600',
        badge: 'bg-indigo-50 text-indigo-500'
      };
    case